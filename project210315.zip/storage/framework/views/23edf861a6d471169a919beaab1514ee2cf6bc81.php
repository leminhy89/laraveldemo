

<?php $__env->startSection('data'); ?>
<div>
  <h1>Danh sách Quyền</h1>
</div>
<br>
<a href="<?php echo e(route('roles.create')); ?>" class="btn btn-success">Thêm Mới Quyền</a>
<br><br>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Description</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($key + 1); ?></th>
        <td><?php echo e($r->id); ?></td>
        <td><?php echo e($r->name); ?></td>
        <td><?php echo e($r->description); ?></td>
        <td> <a href="<?php echo e(route('roles.edit',[$r->id])); ?>" class="btn btn-primary">Cập Nhật</a>  
          <form 
              action="<?php echo e(route('roles.destroy', [$r->id])); ?>"
              method="POST"
          ><?php echo csrf_field(); ?>
              <?php echo e(method_field('DELETE')); ?>

              <button type="submit" class="btn btn-danger">Xóa</button>
          </form>
          
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\learning\laravel\project210315\resources\views/roles/index.blade.php ENDPATH**/ ?>