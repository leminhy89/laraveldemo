

<?php $__env->startSection('data'); ?>
<h1>Edit Role</h1>
<br>

<form action=<?php echo e(route('roles.update', [$role->id])); ?> method="POST"><?php echo csrf_field(); ?>
  <?php echo e(method_field('PUT')); ?>

  <div class="mb-3">
    <label class="form-label">Tên Quyền</label>
    <input name="name" type="text" class="form-control" value=<?php echo e($role->name); ?> id="roleName">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Mô Tả</label>
    <textarea name="description" class="form-control" style="height: 100px">
      <?php echo e($role->description); ?>

    </textarea>
  </div>
  <button type="submit" class="btn btn-primary">Cập Nhật</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\learning\laravel\project210315\resources\views/roles/edit.blade.php ENDPATH**/ ?>