

<?php $__env->startSection('data'); ?>
    <h1>Màn hình tổng hợp</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\learning\laravel\project210315\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>