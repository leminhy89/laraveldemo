

<?php $__env->startSection('data'); ?>
<h1>Create new Role</h1>
<br>

<form action=<?php echo e(route('roles.store')); ?> method="POST"><?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label">Tên Quyền</label>
    <input name="name" type="text" class="form-control" id="roleName">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Mô Tả</label>
    <textarea name="description" class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 100px"></textarea>
  </div>
  <button type="submit" class="btn btn-primary">Tạo</button>
</form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\learning\laravel\project210315\resources\views/roles/create.blade.php ENDPATH**/ ?>