@extends('layouts.admin')

@section('data')
    <h1>Màn hình tổng hợp</h1>
@endsection